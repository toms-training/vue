<template>
  <section class="flex w-full gap-4">
    <article-item v-for="(article, index) in articles" :key="index" :article="article" />
  </section>
</template>

<script>
import ArticleListItem from './ArticleListItem.vue';

export default {
  name: 'ArticleList',
  inheritAttrs: false,
  components: {
    ArticleItem: ArticleListItem
  },
  inject: ['articles']
}
</script>