<template>
    <div class="p-6 flex flex-row flex-wrap w-dvw">
    <h1 class="text-center text-primary text-5xl font-heading-1 mb-8">{{ appTitle }}</h1>
    <article-list />
  </div>
</template>

<script>
import ArticleList from './ArticleList.vue';

    export default {
        components: {
            ArticleList
        },
        props: {
            appTitle: {
                default: 'My App'
            }
        }
    }
</script>