<template>
  <div id="container" class="prose m-5 flex flex-col">
    <p v-bind:id="someId">Hallo Welt</p>
    <p :id="someId">Hallo Welt</p>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      someId: 'id6',
    }
  }
}
</script>

