<template>
  <div class="container prose py-16 px-6 flex flex-col items-center">
    <h1 class="text-center">Spaß mit Vue</h1>
    <div v-show="ampelAnzeigen" class="flex flex-col items-center justify-center p-3 ampel">
      <div v-if="stoppen" class="licht rot"></div>
      <div v-else-if="wechsel" class="licht gelb"></div>
      <div v-else class="licht gruen"></div>
    </div>
    <template v-if="absaetzeAnzeigen">
      <p>Absatz 1</p>
      <p>Absatz 2</p>
      <p>Absatz 3</p>
    </template>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      ampelAnzeigen: true,
      stoppen: false,
      wechsel: false,
      absaetzeAnzeigen: true
    }
  }
}
</script>

<style scoped>
  .container {
    width: calc(100dvw - 20px);
    height: calc(100dvh - 40px);
  }
  
  .ampel {
    background-color: black;
    width: 120px;
  }

  .licht {
    height: 100px;
    width: 100px;
    border-radius: 100px;
    margin: 5px 0;

    &.gruen {
      background-color: greenyellow;
    }

    &.gelb {
      background-color: yellow;
    }

    &.rot {
      background-color: red;
    }
  }
</style>