<template>
  <div class="container prose py-16 px-6 flex flex-col items-center">
    <h1 class="text-center">Spaß mit Vue</h1>
    <section>
      <ul>
      <li v-for="(name, index) in hundeArray" :key="index">
        {{ index }}) {{ name }}
      </li>
    </ul>
    <ul>
      <li v-for="dog in hundeObjekte" :key="dog.name">
        {{ dog.name }} ist {{ dog.alter }} Jahre alt
      </li>
    </ul>
    <ul>
      <li v-for="dog in hundeKlassen" :key="dog.name">
        {{ dog }}
      </li>
    </ul>
    <ul>
      <li v-for="dog in hundeMitArrays" :key="dog.name">
        <h3>{{ dog.name }}</h3>
        <p>{{ dog.alter }} Jahre</p>
        <div>
          <h4>Hobbys</h4>
          <p>
            <span v-for="(hobby, index) in dog.hobbys" :key="index">{{ hobby }} &nbsp;</span>
          </p>
        </div>
      </li>
    </ul>
    <ul>
      <li v-for="(dog, index) in hundeObjekte" :key="dog.name">
        <h3>{{ index }}: {{ dog.name }}</h3>
        <p>{{ dog.alter }} Jahre</p>
      </li>
    </ul>
    <ul>
      <li v-for="(dog) in hundeObjekte" :key="dog.name">
        <p v-for="(value, key, index) in dog" :key="index">
          {{ index }} - {{ key }}: {{ value }}<br>
        </p>
      </li>
    </ul>
    <ul>
      <template v-for="dog in hundeObjekte" :key="dog.name">
        <li v-if="dog.alter === 4">
        {{ dog.name }}
      </li>
      </template>
    </ul>
    </section>
  </div>
</template>

<script>
class Dog {
  name = '';
  alter = 0;

  constructor(name, alter) {
    this.name = name;
    this.alter = alter;
  }

  toString() {
    return `${this.name} ist ${this.alter} Jahre alt`;
  }
}

export default {
  name: 'App',
  data() {
    return {
      hundeArray: [
        'Malou',
        'Karl',
        'Simba',
        'Bubba'
      ],
      hundeObjekte: [
        {name: 'Malou', alter: 4},
        {name: 'Karl', alter: 5},
        {name: 'Simba', alter: 3},
        {name: 'Bubba', alter: 4}
      ],
      hundeKlassen: [
        new Dog('Malou', 4),
        new Dog('Karl', 5)
      ],
      hundeMitArrays: [
        {name: 'Malou', alter: 4, hobbys: ['rennen', 'schlafen']},
        {name: 'Karl', alter: 5, hobbys: ['fressen', 'schlafen']}
      ]
    }
  }
}
</script>

<style scoped>
  .container {
    width: calc(100dvw - 20px);
    height: calc(100dvh - 40px);
  }

  ul {
    width: 100%;
  }

  ul:nth-child(even) {
    background-color: #dedede;
  }
</style>