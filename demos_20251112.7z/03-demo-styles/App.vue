<template>
  <div class="container prose m-5 flex flex-col">
    <h1 class="text-center">Spaß mit Vue</h1>
    <article :style="{
      padding: `${articlePadding}px`,
      fontFamily,
      backgroundColor: articleBackground,
      borderRadius: '5px'
    }">
      <header>
        <h2>Artikel 1</h2>
      </header>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad, assumenda est impedit fugiat quis, architecto, ullam nam odit iure ab quae voluptatibus beatae! Ipsum modi ipsam mollitia amet quod laborum.
      Nostrum tenetur sed, fugit optio provident sit voluptatum tempore ullam molestiae laboriosam dicta dolores praesentium voluptatem odit maxime quo commodi omnis dignissimos labore porro nam officiis atque! Harum, voluptatibus fugiat.
      Accusamus aliquam, dolorum beatae labore ipsa perspiciatis quae hic, eius ducimus illum dicta totam expedita delectus velit porro maiores blanditiis eveniet autem laudantium, molestias sit eum corrupti soluta? Quia, hic.
      Sapiente, blanditiis laborum, doloremque modi nisi quis suscipit debitis itaque, non possimus tenetur maiores. Consequatur vel quo optio inventore natus quidem. Iste quos ipsam sint molestias dolor earum et ipsum?
      Quas qui soluta magni fugit voluptatibus deleniti quibusdam laboriosam quis quasi, inventore id veritatis ipsa odio harum laudantium. Perspiciatis sed illum necessitatibus harum eius ea, consequuntur a exercitationem asperiores voluptatibus!</p>
    </article>
    <article :style="articleStyle">
      <header>
        <h2>Artikel 2</h2>
      </header>
      <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Commodi, distinctio. Maxime inventore, asperiores eaque dolorum magni sapiente assumenda, corporis facere quaerat eum quidem animi maiores architecto explicabo. Quidem, illo facilis?
      Expedita, molestias aperiam. Excepturi facilis consequuntur quaerat odit eveniet commodi alias doloremque quasi corporis vitae eaque quam expedita accusantium quisquam, deserunt voluptate molestiae voluptatum, neque, atque libero illo! Quasi, illo.
      Delectus error, ab nesciunt illum, eum quam vel doloremque, aut quaerat ut exercitationem perferendis? Quisquam aliquid doloribus autem a voluptas perspiciatis tempora ullam illo nisi? Quibusdam debitis expedita aut porro?
      Ipsa veritatis modi quod aliquid enim! Ut placeat, laboriosam, sunt ab libero iste velit recusandae quo dolor blanditiis esse excepturi delectus eum cupiditate similique hic quasi nemo nobis dicta voluptatem?
      Molestias odit nisi facilis ad voluptatem, quod voluptas ducimus ab explicabo nobis eaque, distinctio suscipit cum perferendis ipsum architecto nostrum. Totam incidunt commodi quis quibusdam voluptatem numquam iure architecto nemo.</p>
    </article>
    <article :style="[articleStyle, borderedArticleStyle]">
      <header>
        <h2>Artikel 3</h2>
      </header>
      <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Corrupti, dolorem autem. Tenetur asperiores explicabo pariatur exercitationem placeat culpa fugiat magni libero, quos repellat accusamus earum sunt eligendi? Dolores, iusto odit.
      Voluptatem, numquam in. Facere nemo molestiae minima deserunt quaerat repellat sunt, culpa corporis, quisquam aliquam fugiat alias quam dolorem voluptatum quos laudantium perferendis? Incidunt, animi quas natus cumque quidem quos.
      Ut modi recusandae qui incidunt, vitae deserunt quisquam veritatis nulla consequatur fugiat amet quod odio sed nesciunt corporis blanditiis vero labore obcaecati fuga quae molestiae accusantium ipsam sunt? Explicabo, perferendis?
      Quidem ab explicabo autem nam quos quia, impedit fugiat itaque ad pariatur harum aut! Accusantium tempore culpa aliquam consequuntur ullam voluptate iure, impedit eius, dicta, dolorem et perferendis error. Vel!
      Reiciendis, pariatur! Similique expedita maxime, non ducimus molestiae sapiente culpa repellendus nobis iste aut rem minus asperiores sunt ratione fuga? Fugiat assumenda odio quia modi saepe quisquam molestiae explicabo non!</p>
    </article>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      articlePadding: 12,
      fontFamily: '"Segeo UI", sans-serif',
      articleBackground: '#dd88bb',
      articleStyle: {
        padding: '10px',
        fontFamily: '"Segeo UI", sans-serif',
        backgroundColor: '#dd88cc',
        borderRadius: '5px'
      },
      borderedArticleStyle: {
        border: '3px inset #000099'
      }
    }
  }
}
</script>

<style scoped>
  article {
    margin: 12px 0;
  }
</style>