<template>
  <article class="card card-bordered bg-orange-100 rounded-sm shadow-lg p-4 flex">
    <div class="card-body">
      <h2 class="card-title">{{ article.title }}</h2>
      <p>{{ article.content }}</p>
    </div>
  </article>
  <!-- <p v-bind="$attrs">Absatz</p> -->
</template>

<script>
import { Article } from '@/entities/article';

export default {
  name: 'ArticleComponent',
  inheritAttrs: false,
  data() {
    return {
      
    }
  },
  props: {
    article: {
      type: Article,
      required: true,
      default: new Article('Dummy', 'Dies ist ein Platzhalter')
    }
  }
}
</script>