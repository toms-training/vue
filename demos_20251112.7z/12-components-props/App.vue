<template>
  <div class="p-6 flex flex-row flex-wrap gap-4 w-dvw">
    <Article v-for="(article, index) in articles" :key="index" :article="article" />
    <Article id="some-id" title="Title" />
  </div>
</template>

<script>
import { Article as ArticleEntity } from "./entities/article";
import Article from './components/ArticleComponent.vue';

export default {
  name: 'App',
  data() {
    return {
      articles: [
        new ArticleEntity('Mein erster Artikel', 'Hier kommt mein allererster Artikel'),
        new ArticleEntity('Ein neuer Artikel', 'Langsam füllt sich der Inhalt'),
        new ArticleEntity('Ein weiterer Artikel', 'Ich weiß ich überteibe XD')
      ]
    }
  },
  components: {
    Article,
  }
}
</script>
