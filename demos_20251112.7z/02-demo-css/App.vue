<template>
  <div id="container" class="prose m-5 flex flex-col">
    <p class="highlight">Absatz 1</p>
    <p :class="{ highlight: useHighlight }">Absatz 2</p>
    <p :class="css">Absatz 3</p>
    <p :class="useHighlight ? 'highlight' : 'green'">Absatz 4</p>
    <p :class="[
      'default',
      bold && useHighlight
      ? 'highlight bold'
      : useHighlight
      ? 'highlight'
      : bold
      ? 'bold'
      : useGreen
      ? 'green'
      : 'red'
    ]">Absatz 5</p>
    <p :class="{
      default: true,
      green: useGreen && useHighlight,
      red: useRed && !useHighlight
    }">Absatz 6</p>
    <p>Absatz 7</p>
    <p>Absatz 8</p>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      useHighlight: true,
      isBold: true,
      useGreen: true,
      useRed: true,
      css: {
        highlight: true,
        green: true
      }
    }
  }
}
</script>

<style scoped>
  .highlight {
    color: darkkhaki;
    text-decoration: underline;
  }

  .green {
    background-color: aquamarine;
  }

  .red {
    background-color: maroon;
    color: white;
  }

  .default {
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    font-size: 3rem;
  }

  .bold {
    font-weight: bold;
  }
</style>