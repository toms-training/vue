<template>
  <div class="py-6 px-6 flex flex-row items-center justify-center gap-8 w-dvw h-dvh">
    <section class="p-2 flex flex-wrap items-center justify-between -mx-4 gap-4 w-1/2">
      <form @submit.prevent="submit">
        <div class="form-control">
        <input type="text" placeholder="Name" class="input input-bordered" v-model.trim.lazy="form.name">
      </div>
      <div class="form-control">
        <input type="text" placeholder="Alter" class="input input-bordered" v-model.number="form.alter">
        <input type="number" placeholder="Alter" class="input input-bordered" v-model.number="form.alter2">
      </div>
      <div class="form-control w-full justify-end mt-4">
        <button class="btn btn-primary disabled:cursor-not-allowed disabled:bg-gray-300" :disabled="!isValid()" type="submit">Mach was</button>
      </div>
      </form>
    </section>
    <hr class="w-full rotate-90 m-0">
    <section class="w-1/2" v-if="isValid()" v-once>
      <p v-for="(value, key, index) in form" :key="index" v-pre>
        {{ key.toUpperCase() }}: <b v-if="value" class="underline">|{{ value }}|</b>
      </p>
    </section>
  </div>
</template>

<script>

export default {
  name: 'App',
  data() {
    return {
      form: {
        name: 'Fred',
        alter: null,
        alter2: null
      }
    }
  },
  methods: {
    submit() {
      console.log('Event', event);
      console.log('Form', this.form);
    },
    isValid() {
      return true // this.form.alter > 0 && this.form.name?.length > 0;
    }
  }
}
</script>

<style scoped>
  
</style>