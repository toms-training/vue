<template>
  <div class="py-6 px-6 flex flex-row items-center justify-center gap-8 w-dvw h-dvh">
    <section class="p-2 flex flex-wrap items-center justify-between -mx-4 gap-4 w-1/2">
      <form @submit.prevent="submit">
        <div class="form-control">
          <input type="text" placeholder="Vorname" class="input input-bordered" v-model="firstname">
        </div>
        <div class="form-control">
          <input type="text" placeholder="Nachname" class="input input-bordered" v-model="lastname">
        </div>
        <div class="form-control w-full justify-end mt-4">
          <button class="btn btn-secondary" @click="changeName">Name ändern</button>
          <button class="btn btn-primary" type="submit">Abschicken</button>
        </div>
      </form>
    </section>
    <hr class="w-full rotate-90 m-0">
    <section class="w-1/2">
      <p>{{ output }}</p>
      <p>{{ showOutput() }}</p>
      <p>{{ ausgabe }}</p>
      <p>Name: {{ showFullname() }}</p>
      <p>Name: {{ fullname }}</p>
    </section>
  </div>
</template>

<script>

export default {
  name: 'App',
  data() {
    return {
      firstname: 'Fred',
      lastname: 'Feuerstein',
      output: `Vorname: ${this.firstname}`
    }
  },
  methods: {
    submit() {
      console.log('Event', event);
      console.log('Form', this.form);
    },
    changeName() {
      this.fullname = 'Benjamin Blümchen';
    },
    showFullname() {
      return `${this.firstname} ${this.lastname}`
    },
    showOutput() {
      console.log('showOutput()');
      return `Vorname: ${this.firstname}`;
    }
  },
  computed: {
    ausgabe() {
      console.log('ausgabe() aufgerufen');
      return `Vorname: ${this.firstname}`;
    },
    fullname: {
      get() {
        return `${this.firstname} ${this.lastname}`;
      },
      set(name) {
        const nameParts = name.split(' ');
        this.firstname = nameParts[0];
        this.lastname = nameParts[1];
      }
    }
  }
}
</script>

<style scoped></style>