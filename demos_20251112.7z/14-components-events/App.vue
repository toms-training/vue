<template>
  <app-master />
  <special-input v-model="inputValue" />
  <p>Ausgabe: {{ inputValue }}</p>
</template>

<script>
import { Article as ArticleEntity } from "./entities/article";
import AppMaster from "./components/AppMaster.vue";
import SpecialInput from "./components/SpecialInput.vue";

export default {
  name: 'App',
  data() {
    return {
      articles: [
        new ArticleEntity('Mein erster Artikel', 'Hier kommt mein allererster Artikel'),
        new ArticleEntity('Ein neuer Artikel', 'Langsam füllt sich der Inhalt'),
        new ArticleEntity('Ein weiterer Artikel', 'Ich weiß ich überteibe XD')
      ],
      inputValue: ''
    }
  },
  components: {
    AppMaster,
    SpecialInput
  },
  provide() {
    return {
      articles: this.articles
    }
  }
}
</script>
