<template>
  <section class="flex w-full gap-4 flex-col">
    <article-item v-for="(article, index) in articles" :key="index" :article="article" @details="activateDetails" />
    <section v-if="showDetails">{{ details }}</section>
  </section>
</template>

<script>
import ArticleListItem from './ArticleListItem.vue';

export default {
  name: 'ArticleList',
  inheritAttrs: false,
  components: {
    ArticleItem: ArticleListItem
  },
  inject: ['articles'],
  data() {
    return {
      showDetails: false,
      details: ''
    }
  },
  methods: {
    activateDetails(details) {
      this.showDetails = true;
      this.details = details;
    }
  }
}
</script>