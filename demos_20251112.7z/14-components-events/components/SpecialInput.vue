<template>
    <input type="text" class="input input-bordered" :value="modelValue" @input="$emit('update:modelValue', $event.target.value)">
</template>

<script>
export default {
    name: 'SpecialInput',
    props: {
        modelValue: String
    },
    emits: ['update:modelValue']
}
</script>