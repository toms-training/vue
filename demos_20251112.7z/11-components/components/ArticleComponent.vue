<template>
    <article 
    class="card card-bordered bg-orange-100 rounded-sm shadow-lg p-4 flex">
      <div class="card-body">
        <h2 class="card-title">{{ article.title }}</h2>
        <p>{{ article.content }}</p>
      </div>
    </article>
</template>

<script>
import { Article } from '@/entities/article';

    export default {
        name: 'ArticleComponent',
        data() {
          return {
            article: new Article('Titel', 'Inhalte')
          }
        }
    }
</script>