export class Article {
    constructor(title, content) {
        this.title = title;
        this.content = content;
    }
}