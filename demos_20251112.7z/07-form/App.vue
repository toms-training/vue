<template>
  <div class="py-6 px-6 flex flex-row items-center justify-center gap-8 w-dvw h-dvh">
    <section class="p-2 flex flex-wrap items-center justify-between -mx-4 gap-4 w-1/2">
      <form @submit="submit">
        <div class="form-control">
        <input type="text" placeholder="Name" class="input input-bordered" v-model="form.name">
      </div>
      <div class="form-control">
        <textarea v-model="form.notiz" class="input input-bordered"></textarea>
      </div>
      <div class="form-control">
        <select class="select select-bordered" v-model="form.auswahl">
          <option value="wert1">Wert 1</option>
          <option value="wert2">Wert 2</option>
          <option value="wert3">Wert 3</option>
        </select>
      </div>
      <div class="form-control">
        <select class="select select-bordered" multiple v-model="form.multiAuswahl">
          <option value="wert1">Wert 1</option>
          <option value="wert2">Wert 2</option>
          <option value="wert3">Wert 3</option>
        </select>
      </div>
      <div class="form-control">
        <div class="mr-2">
          <input id="c1" type="checkbox" value="check1" class="checkbox" v-model="form.checkAuswahl">
          Check 1
        </div>
        <div class="mr-2">
          <input id="c2" type="checkbox" value="check2" class="checkbox" v-model="form.checkAuswahl">
          Check 2
        </div>
      </div>
      <div class="form-control">
        <input type="radio" value="radio1" v-model="form.radioAuswahl"> Radio 1<br>
        <input type="radio" value="radio2" v-model="form.radioAuswahl"> Radio 2
      </div>
      <div class="form-control">
        <input type="radio" value="radio3" v-model="form.radioAuswahl2"> Radio 3<br>
        <input type="radio" value="radio4" v-model="form.radioAuswahl2"> Radio 4
      </div>
      <button class="btn" type="submit">Mach was</button>
      </form>
    </section>
    <hr class="w-full rotate-90 m-0">
    <section class="w-1/2">
      <p v-if="form.name.length > 0">Hallo {{ form.name }}!</p>
      <p v-if="form.notiz.length > 0">{{ form.notiz }}</p>
      <p>{{ form.auswahl }}</p>
      <p>Mehrere: {{ form.multiAuswahl }}</p>
      <p>Checks: {{ form.checkAuswahl }}</p>
      <p>Radio: {{  form.radioAuswahl }}</p>
      <p>Radio: {{  form.radioAuswahl2 }}</p>
    </section>
  </div>
</template>

<script>

export default {
  name: 'App',
  data() {
    return {
      form: {
        name: 'Tom',
        notiz: '',
        auswahl: '',
        multiAuswahl: [],
        checkAuswahl: [],
        radioAuswahl: '',
        radioAuswahl2: ''
      }
    }
  },
  methods: {
    submit(event) {
      event.preventDefault();
      console.log('Event', event);
      console.log('Form', this.form);
    }
  }
}
</script>

<style scoped>
  
</style>