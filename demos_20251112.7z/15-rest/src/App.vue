<template>
  <app-master />
</template>

<script>
import { Article as ArticleEntity } from "./entities/article";
import AppMaster from "./components/AppMaster.vue";
import { articlesService } from "./services/articles-service";

export default {
  name: 'App',
  async created() {
    const articles = await articlesService.findAll();
    
    if (articles.length === 0) {
      articlesService.create(new ArticleEntity('Mein erster Artikel', 'Hier kommt mein allererster Artikel'));
      articlesService.create(new ArticleEntity('Ein neuer Artikel', 'Langsam füllt sich der Inhalt'));
      articlesService.create(new ArticleEntity('Ein weiterer Artikel', 'Ich weiß ich überteibe XD'));
    }
  },
  components: {
    AppMaster
  }
}
</script>
