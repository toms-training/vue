<template>
  <section class="flex w-full gap-4 flex-col">
    <article-item v-for="(article, index) in articles" :key="index" :article="article" @details="activateDetails" />
    <section v-if="showDetails">{{ details }}</section>
  </section>
</template>

<script>
import { articlesService } from '@/services/articles-service';
import ArticleListItem from './ArticleListItem.vue';

export default {
  name: 'ArticleList',
  inheritAttrs: false,
  components: {
    ArticleItem: ArticleListItem
  },
  async created() {
    this.articles = await articlesService.findAll();
  },
  data() {
    return {
      showDetails: false,
      details: '',
      articles: []
    }
  },
  methods: {
    activateDetails(details) {
      this.showDetails = true;
      this.details = details;
    }
  }
}
</script>