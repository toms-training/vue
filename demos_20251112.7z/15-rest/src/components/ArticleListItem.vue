<template>
    <article @click="showDetails()" class="card card-bordered bg-orange-100 rounded-sm shadow-lg p-4 flex cursor-pointer">
        <div class="card-body">
            <h2 class="card-title">{{ article.title }}</h2>
        </div>
    </article>
</template>

<script>
import { Article } from '@/entities/article';

export default {
    name: 'ArticleListItem',
    props: {
        article: {
            type: Article
        }
    },
    methods: {
        showDetails() {
            console.log('Details anzeigen');
            this.$emit('details', this.article.content)
        }
    },
    emits: ['details']
}
</script>