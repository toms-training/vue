import { api } from "./axios"

export const articlesService = {
    async findAll(signal) {
        const { data } = await api.get('/articles', { signal });
        return data;
    },
    async findById(id, signal) {
        const { data } = await api.get(`/articles/${id}`, { signal });

        return data;
    },
    async create(payload, signal) {
        const { data } = await api.post('/articles', payload, { signal });

        return data;
    },
    async update(id, payload, signal) {
        const { data } = await api.patch(`/articles/${id}`, payload, { signal });

        return data;
    }
}