<template>
  <div class="prose py-16 px-6 flex flex-row items-center justify-center gap-8 w-dvw h-dvh">
    <section class="card border-2 bg-orange-100 rounded-sm shadow-sm size-60 flex justify-center items-center font-bold">
      <p class="text-xl">{{ aktion.title }}</p>
      <p class="text-5xl">{{ counter }}</p>
    </section>
    <section class="flex flex-col gap-4">
        <button v-on:click="erhoehen($event), aktionAktualisieren('leicht erhöhen')" class="btn btn-circle text-4xl items-baseline bg-orange-300 hover:bg-orange-100">&plus;</button>
        <button v-on:click="verringern($event), aktionAktualisieren('leicht verringern')" class="btn btn-circle text-4xl items-baseline bg-orange-300 hover:bg-orange-100">&dash;</button>
        <button v-on:click="vielErhoehen(5), aktionAktualisieren('stark erhöhen')" class="btn btn-circle text-4xl items-baseline bg-orange-300 hover:bg-orange-100">&plus;&plus;</button>
        <button v-on:click="vielVerringern(5), aktionAktualisieren('stark verringern')" class="btn btn-circle text-4xl items-baseline bg-orange-300 hover:bg-orange-100">&dash;&dash;</button>
    </section>
    <section class="bar">
      <div class="bar-value" :style="{height: counterZuPixel()}"></div>
    </section>
  </div>
</template>

<script>

export default {
  name: 'App',
  data() {
    return {
      counter: -5,
      aktion: {
        title: ''
      }
    }
  },
  methods: {
    erhoehen(event) {
      console.log('Event', event);
      this.counter++;
    },
    verringern(event) {
      console.log('Event', event);
      this.counter--;
    },
    vielErhoehen(anzahl) {
      this.counter += anzahl;
    },
    vielVerringern(anzahl) {
      this.counter -= anzahl;
    },
    counterZuPixel() {
      return `${this.counter}px`;
    },
    aktionAktualisieren(aktion) {
      console.log('aktionAktualisieren()');
      this.aktion.title = aktion;
      //this.aktion = { title: aktion }
    }
  },
  watch: {
    counter: {
      handler(newCounter, oldCounter) {
        console.log('Counter Watcher aufgerufen', oldCounter, newCounter);
        
        if (this.counter < 0) this.counter = 0;
      },
      immediate: true
    },
    aktion: {
      handler(newAktion, oldAktion) {
        console.log('Aktion Watcher aufgerufen', oldAktion, newAktion);
      },
      immediate: true,
      deep: true
    }
  }
}
</script>

<style scoped>
  .bar {
    min-height: 1px;
    width: 30px;

    .bar-value {
      background-color: blue;
    }
  }

  ul {
    display: flex;
    flex-direction: row;
    gap: 25px;
    list-style: none;
  }

  ul:nth-child(even) {
    background-color: #dedede;
  }
</style>